package com.example.irllevelup

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

private val Night = Color(0xFF090D18)
private val Panel = Color(0xFF141C2E)
private val Blue = Color(0xFF5EDBFF)
private val Muted = Color(0xFF9AA8C2)
private val White = Color(0xFFF4F7FF)

data class Quest(val title: String, val detail: String, val xp: Int)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LevelUpApp() }
    }
}

@Composable
fun LevelUpApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("irl_level_up", 0) }
    val today = LocalDate.now().toString()
    val savedDay = prefs.getString("day", "") ?: ""
    val quests = remember {
        listOf(
            Quest("Move your body", "Complete today's planned workout", 40),
            Quest("Step mission", "Reach your daily step target", 25),
            Quest("Protein mission", "Hit your protein goal", 25),
            Quest("Log your weight", "Record your morning weight", 10),
            Quest("Recovery protocol", "Wind down and get enough sleep", 15)
        )
    }
    val checked = remember {
        mutableStateListOf<Boolean>().apply {
            quests.indices.forEach { i ->
                add(if (savedDay == today) prefs.getBoolean("q$i", false) else false)
            }
        }
    }
    var weight by remember { mutableStateOf(prefs.getString("weight", "") ?: "") }
    var showWeight by remember { mutableStateOf(false) }
    val xp = quests.indices.filter { checked[it] }.sumOf { quests[it].xp }
    val totalXp = (prefs.getInt("totalXp", 0) + xp)
    val level = 1 + totalXp / 250
    val rank = when {
        level >= 25 -> "S-RANK"
        level >= 15 -> "A-RANK"
        level >= 9 -> "B-RANK"
        level >= 5 -> "C-RANK"
        level >= 3 -> "D-RANK"
        else -> "E-RANK"
    }
    val progress = (totalXp % 250) / 250f

    MaterialTheme(colorScheme = darkColorScheme(
        background = Night, surface = Panel, primary = Blue,
        onBackground = White, onSurface = White
    )) {
        Surface(modifier = Modifier.fillMaxSize(), color = Night) {
            Column(
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("IRL LEVEL UP", color = Blue, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Text("SYSTEM ONLINE", color = Muted, fontSize = 11.sp)
                    }
                    Surface(color = Color(0xFF18344A), shape = RoundedCornerShape(50)) {
                        Text("● ACTIVE", color = Blue, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Surface(color = Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("PLAYER STATUS", color = Muted, fontSize = 12.sp, letterSpacing = 2.sp)
                        Row(verticalAlignment = Alignment.Bottom) {
                            Column(Modifier.weight(1f)) {
                                Text("HUNTER", color = White, fontSize = 26.sp, fontWeight = FontWeight.Black)
                                Text(rank, color = Blue, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("LEVEL $level", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                Text("$totalXp XP TOTAL", color = Muted, fontSize = 11.sp)
                            }
                        }
                        LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(8.dp), color = Blue, trackColor = Color(0xFF29344A))
                        Text("${totalXp % 250} / 250 XP TO NEXT LEVEL", color = Muted, fontSize = 11.sp)
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("BODY", "BUILD", Modifier.weight(1f))
                    StatCard("DISCIPLINE", "GROW", Modifier.weight(1f))
                    StatCard("STREAK", "${checked.count { it }} / ${quests.size}", Modifier.weight(1f))
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("DAILY QUESTS", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("Clear missions. Earn XP. Repeat.", color = Muted, fontSize = 12.sp)
                    }
                    Text("+$xp XP", color = Blue, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }

                quests.forEachIndexed { index, quest ->
                    Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = checked[index],
                                onCheckedChange = { value ->
                                    checked[index] = value
                                    if (prefs.getString("day", "") != today) {
                                        val reset = prefs.edit().putString("day", today)
                                        quests.indices.forEach { reset.remove("q$it") }
                                        reset.apply()
                                    }
                                    prefs.edit().putBoolean("q$index", value).apply()
                                },
                                colors = CheckboxDefaults.colors(checkedColor = Blue, uncheckedColor = Muted)
                            )
                            Column(Modifier.weight(1f)) {
                                Text(quest.title, color = White, fontWeight = FontWeight.SemiBold)
                                Text(quest.detail, color = Muted, fontSize = 12.sp)
                            }
                            Text("+${quest.xp}", color = if (checked[index]) Blue else Muted, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("BODY LOG", color = White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text("Track your morning weight (kg)", color = Muted, fontSize = 12.sp)
                        OutlinedTextField(
                            value = weight,
                            onValueChange = { weight = it },
                            label = { Text("Weight in kg") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = White, unfocusedTextColor = White,
                                focusedBorderColor = Blue, unfocusedBorderColor = Muted,
                                focusedLabelColor = Blue, unfocusedLabelColor = Muted
                            )
                        )
                        Button(
                            onClick = {
                                prefs.edit().putString("weight", weight).apply()
                                showWeight = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Blue, contentColor = Night),
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("SAVE WEIGHT", fontWeight = FontWeight.Bold) }
                        if (showWeight && weight.isNotBlank()) Text("Saved: $weight kg", color = Blue, fontSize = 12.sp)
                    }
                }

                Button(
                    onClick = {
                        prefs.edit().putString("day", today).putInt("totalXp", totalXp).apply()
                        quests.indices.forEach { checked[it] = false }
                        val reset = prefs.edit()
                        quests.indices.forEach { reset.remove("q$it") }
                        reset.apply()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22324B), contentColor = Blue)
                ) { Text("SYNC TODAY'S PROGRESS", fontWeight = FontWeight.Bold) }

                Text("Build consistency, not perfection. Rest is part of progress.", color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = modifier) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            Text(value, color = Blue, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
    }
}
