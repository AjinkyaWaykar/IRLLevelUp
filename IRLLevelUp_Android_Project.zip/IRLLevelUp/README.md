# IRL Level Up — Android starter project

An original anime/RPG-inspired fitness and daily-quest tracker built with Kotlin and Jetpack Compose.

## Included in this MVP
- Dark neon player status screen
- Daily quest checklist with XP rewards
- Level and E-to-S style rank progression
- Weight entry saved locally
- Basic local persistence using Android SharedPreferences
- No account, analytics, ads, or network permissions

## Build an APK locally
1. Install Android Studio: https://developer.android.com/studio
2. Extract this ZIP and open the `IRLLevelUp` folder in Android Studio.
3. Allow Gradle sync to finish. If prompted, install Android SDK Platform 35.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

## Build an APK using GitHub Actions
This project includes `.github/workflows/build-apk.yml`.
1. Create a GitHub repository and upload the extracted project files.
2. Push the files to the `main` branch, or open **Actions → Build Android APK → Run workflow**.
3. When the workflow succeeds, open its run, find **Artifacts**, and download `IRLLevelUp-debug-apk`.
4. Extract the artifact to get `app-debug.apk`, then install it on your Android phone. Android may ask you to allow installs from your file manager/browser.

## Notes
- This is a starter MVP, not a production-ready release.
- The APK from this workflow is a debug build, suitable for personal testing; it is not a Play Store release build.
- Progression persistence is intentionally simple and should be improved before public release. The next iteration should store daily XP once per day, keep history, and add settings for goals/equipment.
- Workout suggestions are not medical advice. Adjust training to your ability and recover appropriately.
- The app is inspired by a general gamified fitness concept but uses an original name and UI. It does not use Arise/Solo Leveling assets or code.
